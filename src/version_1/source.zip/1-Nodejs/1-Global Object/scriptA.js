var firstName = 'Sadık';

